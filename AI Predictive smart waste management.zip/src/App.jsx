import React, { useState } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useLocation 
} from 'react-router-dom';
import { 
  LayoutDashboard, 
  Trash2, 
  Brain, 
  MapPin, 
  FileText, 
  Camera,
  Menu,
  LogOut,
  Recycle
} from 'lucide-react';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import SmartBins from './pages/SmartBins';
import Predictions from './pages/Predictions';
import RouteOptimization from './pages/RouteOptimization';
import Reports from './pages/Reports';
import WasteClassification from './pages/WasteClassification';

const Sidebar = ({ isOpen, toggle }) => {
  const location = useLocation();
  const menuItems = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/bins', label: 'Smart Bins', icon: Trash2 },
    { path: '/predictions', label: 'AI Forecasting', icon: Brain },
    { path: '/optimization', label: 'Route Optimization', icon: MapPin },
    { path: '/classification', label: 'Waste Classification', icon: Camera },
    { path: '/reports', label: 'Reports', icon: FileText },
  ];

  if (location.pathname === '/') return null;

  return (
    <div className={`fixed left-0 top-0 h-full bg-white border-r border-border transition-all duration-300 z-50 ${isOpen ? 'w-72' : 'w-20'}`}>
      <div className="p-6 flex items-center justify-between border-b border-border">
        <div className={`flex items-center gap-3 ${!isOpen && 'hidden'}`}>
          <div className="p-2 bg-secondary rounded-lg">
            <Recycle className="text-white" size={20} />
          </div>
          <span className="font-bold text-primary text-xl tracking-tight">SWR Waste</span>
        </div>
        <button onClick={toggle} className="p-2 hover:bg-muted rounded-lg transition-colors text-primary">
          <Menu size={20} />
        </button>
      </div>

      <nav className="mt-6 px-3 space-y-1">
        {menuItems.map((item) => (
          <Link 
            key={item.path} 
            to={item.path}
            className={`flex items-center gap-3 p-3 rounded-xl transition-all group ${
              location.pathname === item.path 
                ? `bg-primary text-white shadow-lg shadow-primary/20` 
                : 'text-gray-500 hover:text-primary hover:bg-muted'
            }`}
          >
            <div className={`transition-transform group-hover:scale-110`}>
              <item.icon size={20} />
            </div>
            <span className={`font-medium transition-all duration-300 ${!isOpen && 'opacity-0 pointer-events-none'}`}>
              {item.label}
            </span>
          </Link>
        ))}
      </nav>

      <div className={`absolute bottom-6 left-4 right-4 ${!isOpen && 'hidden'}`}>
        <div className="p-4 bg-muted rounded-2xl border border-border">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">
              K
            </div>
            <div>
              <p className="text-primary font-bold text-sm">Karthik</p>
              <p className="text-gray-500 text-xs">Administrator</p>
            </div>
          </div>
          <Link to="/" className="w-full py-2 bg-white border border-border hover:border-red-200 hover:text-red-500 text-gray-500 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-2">
            <LogOut size={14} />
            Sign Out
          </Link>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <Router>
      <AppContent isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
    </Router>
  );
}

function AppContent({ isSidebarOpen, setIsSidebarOpen }) {
  const location = useLocation();
  const isHomePage = location.pathname === '/';

  return (
    <div className="min-h-screen bg-muted text-ink font-sans selection:bg-secondary selection:text-white">
      {!isHomePage && (
        <Sidebar isOpen={isSidebarOpen} toggle={() => setIsSidebarOpen(!isSidebarOpen)} />
      )}
      
      <main className={`transition-all duration-300 ${!isHomePage ? (isSidebarOpen ? 'ml-72' : 'ml-20') : ''} ${!isHomePage ? 'p-8' : ''}`}>
        <div className={!isHomePage ? "max-w-7xl mx-auto" : ""}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/bins" element={<SmartBins />} />
            <Route path="/predictions" element={<Predictions />} />
            <Route path="/optimization" element={<RouteOptimization />} />
            <Route path="/classification" element={<WasteClassification />} />
            <Route path="/reports" element={<Reports />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

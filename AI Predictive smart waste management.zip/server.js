import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || "eco-waste-secret-key-2026";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // MongoDB Connection
  const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/smart_waste";
  let isDbConnected = false;

  mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 5000 })
    .then(() => {
      console.log("Connected to MongoDB");
      isDbConnected = true;
    })
    .catch(err => {
      console.error("MongoDB connection error (falling back to in-memory storage):", err.message);
      isDbConnected = false;
    });

  // In-memory fallback data
  let memoryBins = [
    { _id: "1", location: "Main Square", fillLevel: 45, status: "Moderate", lat: 13.0827, lng: 80.2707, lastUpdated: new Date() },
    { _id: "2", location: "Central Park", fillLevel: 85, status: "Full", lat: 13.0850, lng: 80.2101, lastUpdated: new Date() },
    { _id: "3", location: "Market St", fillLevel: 20, status: "Empty", lat: 13.0400, lng: 80.2400, lastUpdated: new Date() },
    { _id: "4", location: "Tech Hub", fillLevel: 65, status: "Moderate", lat: 12.9716, lng: 80.2452, lastUpdated: new Date() },
  ];

  // Models
  const UserSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    role: { type: String, default: "officer" }
  });
  const User = mongoose.model("User", UserSchema);

  const BinSchema = new mongoose.Schema({
    location: String,
    fillLevel: Number,
    status: String,
    lat: Number,
    lng: Number,
    lastUpdated: { type: Date, default: Date.now }
  });
  const Bin = mongoose.model("Bin", BinSchema);

  app.use(cors());
  app.use(express.json());

  // --- API Routes ---
  
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    // Hardcoded demo admin - Updated to karthik@gmail.com / 12345
    if (email === "karthik@gmail.com" && password === "12345") {
      const token = jwt.sign({ email: "karthik@gmail.com", role: "admin" }, JWT_SECRET);
      return res.json({ token, user: { name: "Karthik", email: "karthik@gmail.com", role: "admin" } });
    }

    if (!isDbConnected) {
      return res.status(401).json({ message: "Database offline. Use karthik@gmail.com / 12345" });
    }

    try {
      const user = await User.findOne({ email });
      if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET);
        res.json({ token, user: { name: user.name, email: user.email, role: user.role } });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (err) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Smart Bins API
  app.get("/api/bins", async (req, res) => {
    if (!isDbConnected) {
      return res.json(memoryBins);
    }

    try {
      let bins = await Bin.find();
      if (bins.length === 0) {
        // Seed initial data
        const initialBins = [
          { location: "Main Square", fillLevel: 45, status: "Moderate", lat: 13.0827, lng: 80.2707 },
          { location: "Central Park", fillLevel: 85, status: "Full", lat: 13.0850, lng: 80.2101 },
          { location: "Market St", fillLevel: 20, status: "Empty", lat: 13.0400, lng: 80.2400 },
          { location: "Tech Hub", fillLevel: 65, status: "Moderate", lat: 12.9716, lng: 80.2452 },
        ];
        await Bin.insertMany(initialBins);
        bins = await Bin.find();
      }
      res.json(bins);
    } catch (err) {
      console.error("Error fetching bins from DB:", err);
      res.json(memoryBins); // Fallback even if query fails
    }
  });

  app.post("/api/bins/:id/update", async (req, res) => {
    const { id } = req.params;
    const { fillLevel } = req.body;
    const status = fillLevel > 80 ? "Full" : fillLevel > 40 ? "Moderate" : "Empty";

    if (!isDbConnected) {
      const binIndex = memoryBins.findIndex(b => b._id === id);
      if (binIndex !== -1) {
        memoryBins[binIndex] = { ...memoryBins[binIndex], fillLevel, status, lastUpdated: new Date() };
        return res.json(memoryBins[binIndex]);
      }
      return res.status(404).json({ message: "Bin not found in memory" });
    }

    try {
      const bin = await Bin.findByIdAndUpdate(id, { fillLevel, status, lastUpdated: new Date() }, { new: true });
      res.json(bin);
    } catch (err) {
      res.status(400).json({ message: "Error updating bin" });
    }
  });

  // Waste Prediction Mock Data - Realistic Forecast with Festival Spikes
  app.get("/api/predictions", (req, res) => {
    const data = {
      labels: ["Mar 25", "Mar 26", "Mar 27", "Mar 28", "Mar 29", "Mar 30", "Mar 31", "Apr 01", "Apr 02", "Apr 03", "Apr 04", "Apr 05"],
      // Actual waste stops at "Today" (Mar 27)
      actual: [458, 442, 521, null, null, null, null, null, null, null, null, null], 
      // Forecasts start from the last actual point (Mar 27)
      arima: [null, null, 521, 538, 522, 514, 528, 506, 498, 552, 574, 588],
      lstm: [null, null, 521, 554, 538, 518, 531, 522, 512, 568, 584, 602],
      randomForest: [null, null, 521, 548, 532, 508, 526, 512, 504, 558, 578, 594],
      xgboost: [null, null, 521, 562, 544, 522, 541, 528, 518, 578, 598, 618],
      accuracy: "97.4%",
      rmse: "8.2",
      festival: "Good Friday / Easter Weekend"
    };
    res.json(data);
  });

  // --- Vite Integration ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
